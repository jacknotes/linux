<VERSION>4.1.0</VERSION>
<SQLQUERY>
<REMARK>
[����]

[Ӧ�ñ���]

[���������]

[��Ҫ�Ĳ�ѯ����]

[ʵ�ַ���]

[����]
</REMARK>
<BEFORERUN>
declare
    VBGDDATE  DATE ;
    VENDDATE  DATE ;
begin
    
    delete from  h4rtmp_storealcctrluc ; 
    commit ;
    delete from  h4rtmp_storealcctrl ; 
    commit ;

    --------��� ��ʼ��ֹʱ��
    VBGDDATE :=TO_DATE('\(1,1)' , 'YYYY.MM.DD') ;
    VENDDATE :=TO_DATE('\(2,1)' , 'YYYY.MM.DD') ;

    IF '\(1,1)' IS NULL THEN VBGDDATE := TO_DATE('2008.04.01' , 'YYYY.MM.DD'); END IF ; 

    IF '\(2,1)' IS NULL THEN VENDDATE := SYSDATE ; END IF ;
      
     
    ----------������ʼʱ��ǰһ�����ϵ���� ��Ϊ�ڳ�
    insert into h4rtmp_storealcctrl(storecode ,fildate ,actcls ,srccls ,srcnum ,alctotal,note,line)  ---ʹ�� line ����Ϊ���� 0 ��ʾ�������� 1 ��ʾ���������ʽ��ʻ����
    select storegid , adate + 1 , actcls , to_char(adate,'yyyymmdd')||'�������', 
          to_char(adate,'yyyymmdd')||'�������', total , '' , - 1
     from  invstorealcctrldtl 
       WHERE ADATE = VBGDDATE - 1 ;

   ------------���ѳ�ֵ ������ֵ״̬����
   /* insert into h4rtmp_storealcctrluc(storegid ,fildate ,actcls , srccls ,srcnum , alctotal , teltotal , watertotal , crmtotal , flag)
    select storegid , trunc(fildate) , '��ͨ' , '����' ,
    to_char(fildate,'yyyymmdd')||decode( stat ,600 , '�ɹ�',900 , decode( autostat ,3 ,'��ֵʧ��',1,'����ֵ', decode(manualstat ,1 , '����ֵ')) ,910 , 'ʧ���˿�','δ�ɹ�')||'����' ,
     - sum(payamount) , - sum(payamount) , 0 , 0 , 0
     from telefillup where stat >= 100 
        AND FILDATE < VENDDATE + 1
        AND FILDATE >= VBGDDATE   
      group by storegid , trunc(fildate) , 
      to_char(fildate,'yyyymmdd')||decode( stat ,600 , '�ɹ�',900 , decode( autostat ,3 ,'��ֵʧ��',1,'����ֵ', decode(manualstat ,1 , '����ֵ')) ,910 , 'ʧ���˿�','δ�ɹ�')||'����'
      order by trunc(fildate);        

   ------------���ѳ�ֵ �����쳣����ͨ��JOB�����ʽ�
    insert into h4rtmp_storealcctrluc(storegid ,fildate ,actcls , srccls ,srcnum , alctotal , teltotal , watertotal , crmtotal , flag)
    select store  , trunc(OCRDATE) , '��ͨ' , '���ѳ�ֵʧ�ܷ���' ,
    to_char(OCRDATE,'yyyymmdd')||'ʧ�ܻ����ʽ𷵻�' ,
      sum(alctotal) ,  sum(alctotal) , 0 , 0 , 0
     from storealcctrllog where srccls = '���ѳ�ֵʧ�ܷ���' 
	AND OCRDATE < VENDDATE + 1
        AND OCRDATE >= VBGDDATE   
      group by store  , trunc(OCRDATE) , 
      to_char(OCRDATE,'yyyymmdd')||'ʧ�ܻ����ʽ𷵻�' 
      ;  
                 
   ---------ˮ�ѳ�ֵ�� ����ֵ״̬����   
    insert into h4rtmp_storealcctrluc(storegid ,fildate ,actcls , srccls ,srcnum , alctotal , teltotal , watertotal , crmtotal, flag)
    select storegid , trunc(fildate) , '��ͨ' , 'ˮ��' ,
    to_char(fildate,'yyyymmdd')||decode( stat ,900, '�ɹ�', 100 ,'����ֵ','δ�ɹ�')||'ˮ��' ,
    -sum(payamount)  , 0 , -sum(payamount) ,0 ,0
       from watercashbill where stat >= 100
        AND FILDATE < VENDDATE + 1
        AND FILDATE >= VBGDDATE 
         group by storegid , trunc(fildate) ,
         to_char(fildate,'yyyymmdd')||decode( stat ,900, '�ɹ�' , 100 ,'����ֵ','δ�ɹ�')||'ˮ��' 
       order by trunc(fildate);    
  
   -------��Ա����ֵ 
    insert into h4rtmp_storealcctrluc(storegid ,fildate ,actcls , srccls ,srcnum ,alctotal  , teltotal , watertotal , crmtotal , flag)   
    select store ,trunc(lstupdtime) ,'��ͨ' , '��Ա��' ,to_char(lstupdtime,'yyyymmdd')||'��Ա��' ,  - sum(amount) , 0 , 0 , - sum(amount) ,0 
        from CRMCashStoreLog
         WHERE lstupdtime < VENDDATE + 1
         AND lstupdtime >= VBGDDATE 
      group by store , trunc(lstupdtime) ,to_char(lstupdtime,'yyyymmdd')||'��Ա��'
         order by trunc(lstupdtime) ;
   */
    insert into h4rtmp_storealcctrluc(storegid ,fildate ,actcls  , srccls ,srcnum , alctotal , teltotal , watertotal , crmtotal , flag )
    select storegid , fildate , actcls , '�ϼ�' , '�ϼ�' , sum(alctotal) , sum(teltotal) , sum(watertotal) , sum(crmtotal) , 1 
     from  h4rtmp_storealcctrluc where flag = 0
      group by storegid , fildate , actcls  ;
     
    commit ;   
    -------�ϼƵ�һ�ű�����

    
    ------------���ŵ�ɿ�Ϳۿ�ı�ע��ʾ����
    insert into h4rtmp_storealcctrl(storecode ,fildate ,actcls ,srccls ,srcnum ,alctotal,note,line)
    select a.store , trunc(a.ocrdate) , a.actcls , a.srccls, a.srcnum  , sum(a.alctotal) , b.note , 0
    from storealcctrllog a, storealcpay b 
        where a.srcnum = b.num(+)
         and decode(a.srccls,'���˽�ɿ�','�ɿ�','���˽�ۿ�','�ۿ�' ,a.srccls) = b.cls(+)
         and a.srccls not in ('���˵��տ�','�ۼ����˽�')
         AND OCRDATE < VENDDATE + 1
         AND OCRDATE >= VBGDDATE 
        group by trunc(ocrdate) , a.store , a.actcls , a.srcnum , a.srccls , b.note;    
    
    ---------��Ӧ�ʽ�ۼ�����ϸ 
    insert into h4rtmp_storealcctrl(storecode ,fildate ,actcls ,srccls ,srcnum ,alctotal,note,line)
    select storegid , fildate , actcls ,srccls ,srcnum , alctotal ,'' , 0
       from   h4rtmp_storealcctrluc where flag = 0 ;
        
    -------------------���� 1-3�ţ����ǲ���ʹ���ŵ�ɿ�������ŵ��տ�϶��տ����ֱ�ӳ����ʽ��ʻ�
    insert into h4rtmp_storealcctrl(storecode ,fildate ,actcls ,srccls ,srcnum ,alctotal,note,line)  ---ʹ�� line ����Ϊ���� 0 ��ʾ�������� 1 ��ʾ���������ʽ��ʻ����
    select a.store , trunc(a.ocrdate) , a.actcls ,'�ŵ��տ', a.srcnum  , sum(a.alctotal) , '�ŵ��տ'||a.srcnum||'���տ�' , 0
      from storealcctrllog a
        where a.srccls = '���˵��տ�'
         AND OCRDATE < VENDDATE + 1
         AND OCRDATE >= VBGDDATE 
        group by trunc(ocrdate) , a.store , a.actcls , a.srcnum , a.srccls  ;   
     
    ----------����ÿ�����ϵ���� 
    insert into h4rtmp_storealcctrl(storecode ,fildate ,actcls ,srccls ,srcnum ,alctotal,note,line)  ---ʹ�� line ����Ϊ���� 0 ��ʾ�������� 1 ��ʾ���������ʽ��ʻ����
    select storegid , adate , actcls , to_char(adate,'yyyymmdd')||'�������', 
          to_char(adate,'yyyymmdd')||'�������', total , '' ,1
     from  invstorealcctrldtl
       WHERE ADATE <= VENDDATE AND ADATE >= VBGDDATE ;
                              
    ----------���뵱ǰ�ʽ��ʻ����
    insert into h4rtmp_storealcctrl(storecode ,fildate ,actcls ,srccls ,srcnum ,alctotal,note,line)  ---ʹ�� line ����Ϊ���� 0 ��ʾ�������� 1 ��ʾ���������ʽ��ʻ����
    select storegid , sysdate , actcls , to_char(sysdate,'yyyymmdd')||'��ǰ���', 
          to_char(sysdate,'yyyymmdd')||'��ǰ���', total , '' ,1
     from  storealcctrldtl 
       WHERE SYSDATE < VENDDATE + 1
         AND SYSDATE >= VBGDDATE ;

    commit ;  
     -------�����ܲ���˵�ʽ��ʻ�������
    delete from  h4rtmp_storealcctrl where storecode = 1000000;  
    commit ;
end;
</BEFORERUN>
<AFTERRUN>
</AFTERRUN>
<TABLELIST>
  <TABLEITEM>
    <TABLE>h4rtmp_storealcctrl</TABLE>
    <ALIAS>h4rtmp_storealcctrl</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
  <TABLEITEM>
    <TABLE>STORE</TABLE>
    <ALIAS>STORE</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
</TABLELIST>
<JOINLIST>
  <JOINITEM>
    <LEFT>h4rtmp_storealcctrl.storecode</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>STORE.GID</RIGHT>
  </JOINITEM>
</JOINLIST>
<COLUMNLIST>
  <FIXEDCOLUMNS>0</FIXEDCOLUMNS>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>STORE.CODE</COLUMN>
    <TITLE>�ŵ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>CODE</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>STORE.NAME</COLUMN>
    <TITLE>�ŵ�����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>NAME</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN> (case when 
                  (DECODE(BITAND(STORE.PROPERTY, 4), 4, 1, 0)
       		+ DECODE(BITAND(STORE.PROPERTY,  64),  64, 1, 0)
       		+ DECODE(BITAND(STORE.PROPERTY, 256), 256, 1, 0)) = 0 then 'ֱӪ' 
                  else '����' end) </COLUMN>
    <TITLE>��λ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>PROPERTY</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.fildate</COLUMN>
    <TITLE>����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>fildate</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.actcls</COLUMN>
    <TITLE>�ʻ�����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>actcls</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.srccls</COLUMN>
    <TITLE>��Դ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>srccls</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.srcnum</COLUMN>
    <TITLE>��Դ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>srcnum</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.alctotal</COLUMN>
    <TITLE>�ʽ�ʹ�����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>alctotal</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>2228989</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.note</COLUMN>
    <TITLE>��ע</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>note</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>h4rtmp_storealcctrl.line</COLUMN>
    <TITLE>�����־</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>line</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
</COLUMNLIST>
<COLUMNWIDTH>
  <COLUMNWIDTHITEM>72</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>188</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>54</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>112</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>88</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>104</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>116</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>78</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>260</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
</COLUMNWIDTH>
<GROUPLIST>
</GROUPLIST>
<ORDERLIST>
  <ORDERITEM>
    <COLUMN>�ŵ����</COLUMN>
    <ORDER>ASC</ORDER>
  </ORDERITEM>
  <ORDERITEM>
    <COLUMN>�����־</COLUMN>
    <ORDER>ASC</ORDER>
  </ORDERITEM>
  <ORDERITEM>
    <COLUMN>�ʻ�����</COLUMN>
    <ORDER>ASC</ORDER>
  </ORDERITEM>
  <ORDERITEM>
    <COLUMN>����</COLUMN>
    <ORDER>ASC</ORDER>
  </ORDERITEM>
</ORDERLIST>
<CRITERIALIST>
  <WIDTHLIST>
  </WIDTHLIST>
  <CRITERIAITEM>
    <LEFT>h4rtmp_storealcctrl.fildate</LEFT>
    <OPERATOR>>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2010.06.24</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>����</DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>h4rtmp_storealcctrl.fildate</LEFT>
    <OPERATOR><</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2010.06.25</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>����</DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>STORE.CODE</LEFT>
    <OPERATOR>IN</OPERATOR>
    <RIGHT>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>STORE.CODE</LEFT>
    <OPERATOR>LIKE</OPERATOR>
    <RIGHT>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
</CRITERIALIST>
<CRITERIAWIDTH>
  <CRITERIAWIDTHITEM>89</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>134</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>137</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>88</CRITERIAWIDTHITEM>
</CRITERIAWIDTH>
<SG>
  <LINE>
  </LINE>
  <LINE>
    <SGLINEITEM>���� 1��</SGLINEITEM>
    <SGLINEITEM>2010.06.24</SGLINEITEM>
    <SGLINEITEM>2010.06.25</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 2��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 3��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 4��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
  </LINE>
</SG>
<CHECKLIST>
  <CAPTION>
  </CAPTION>
  <EXPRESSION>
  </EXPRESSION>
  <CHECKED>
  </CHECKED>
  <ANDOR> and </ANDOR>
</CHECKLIST>
<UNIONLIST>
</UNIONLIST>
<NCRITERIAS>
  <NUMOFNEXTQRY>3</NUMOFNEXTQRY>
  <NCRITERIALIST>
    <NEXTQUERY>�ŵ��ʽ��ʻ�����_��ϸ��ˮ��.sql</NEXTQUERY>
    <NCRITERIAITEM>
      <LEFT>���ڴ��ڵ���</LEFT>
      <RIGHT>���ڴ��ڵ���</RIGHT>
    </NCRITERIAITEM>
    <NCRITERIAITEM>
      <LEFT>����С�ڵ���</LEFT>
      <RIGHT>����С�ڵ���</RIGHT>
    </NCRITERIAITEM>
    <NCRITERIAITEM>
      <LEFT>�ŵ������֮��</LEFT>
      <RIGHT>�ŵ����</RIGHT>
    </NCRITERIAITEM>
  </NCRITERIALIST>
  <NCRITERIALIST>
    <NEXTQUERY>���˵�ɿۿ��.sql</NEXTQUERY>
    <NCRITERIAITEM>
      <LEFT>�ʱ����ڵ���</LEFT>
      <RIGHT>���ڴ��ڵ���</RIGHT>
    </NCRITERIAITEM>
    <NCRITERIAITEM>
      <LEFT>�ŵ������֮��</LEFT>
      <RIGHT>�ŵ����</RIGHT>
    </NCRITERIAITEM>
    <NCRITERIAITEM>
      <LEFT>������֮��</LEFT>
      <RIGHT>��Դ����</RIGHT>
    </NCRITERIAITEM>
  </NCRITERIALIST>
  <NCRITERIALIST>
    <NEXTQUERY>�ŵ��տ����.sql</NEXTQUERY>
    <NCRITERIAITEM>
      <LEFT>�տ�ʱ����ڵ���</LEFT>
      <RIGHT>����</RIGHT>
    </NCRITERIAITEM>
    <NCRITERIAITEM>
      <LEFT>�ŵ������֮��</LEFT>
      <RIGHT>�ŵ����</RIGHT>
    </NCRITERIAITEM>
    <NCRITERIAITEM>
      <LEFT>�տ�ʱ��С��</LEFT>
      <RIGHT>����С�ڵ���</RIGHT>
    </NCRITERIAITEM>
  </NCRITERIALIST>
</NCRITERIAS>
<MULTIQUERIES>
  <NUMOFMULTIQRY>0</NUMOFMULTIQRY>
</MULTIQUERIES>
<FUNCTIONLIST>
</FUNCTIONLIST>
<DXDBGRIDITEM>
  <DXLOADMETHOD>FALSE</DXLOADMETHOD>
  <DXSHOWGROUP>FALSE</DXSHOWGROUP>
  <DXSHOWFOOTER>TRUE</DXSHOWFOOTER>
  <DXSHOWSUMMARY>FALSE</DXSHOWSUMMARY>
  <DXSHOWPREVIEW>FALSE</DXSHOWPREVIEW>
  <DXSHOWFILTER>FALSE</DXSHOWFILTER>
  <DXPREVIEWFIELD></DXPREVIEWFIELD>
  <DXCOLORODDROW>16252902</DXCOLORODDROW>
  <DXCOLOREVENROW>15269373</DXCOLOREVENROW>
  <DXFILTERNAME></DXFILTERNAME>
  <DXFILTERLIST>
  </DXFILTERLIST>
  <DXSHOWGRIDLINE>1</DXSHOWGRIDLINE>
</DXDBGRIDITEM>
</SQLQUERY>
<SQLREPORT>
<RPTTITLE>�ŵ��ʽ��ʻ�����</RPTTITLE>
<RPTGROUPCOUNT>0</RPTGROUPCOUNT>
<RPTGROUPLIST>
</RPTGROUPLIST>
<RPTCOLUMNCOUNT>10</RPTCOLUMNCOUNT>
<RPTCOLUMNWIDTHLIST>
  <RPTCOLUMNWIDTHITEM>72</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>128</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>54</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>112</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>88</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>104</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>116</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>78</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>260</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>56</RPTCOLUMNWIDTHITEM>
</RPTCOLUMNWIDTHLIST>
<RPTLEFTMARGIN>20</RPTLEFTMARGIN>
<RPTORIENTATION>0</RPTORIENTATION>
<RPTCOLUMNS>1</RPTCOLUMNS>
<RPTHEADERLEVEL>0</RPTHEADERLEVEL>
<RPTPRINTCRITERIA>TRUE</RPTPRINTCRITERIA>
<RPTVERSION></RPTVERSION>
<RPTNOTE></RPTNOTE>
<RPTFONTSIZE>10</RPTFONTSIZE>
<RPTLINEHEIGHT>����</RPTLINEHEIGHT>
<RPTPAGEHEIGHT>66</RPTPAGEHEIGHT>
<RPTPAGEWIDTH>80</RPTPAGEWIDTH>
<RPTTITLETYPE>0</RPTTITLETYPE>
<RPTCURREPORT></RPTCURREPORT>
<RPTREPORTLIST>
</RPTREPORTLIST>
</SQLREPORT>

