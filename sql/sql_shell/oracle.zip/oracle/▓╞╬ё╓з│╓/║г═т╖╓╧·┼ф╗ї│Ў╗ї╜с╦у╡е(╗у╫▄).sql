<VERSION>4.1.1</VERSION>
<SQLQUERY>
<REMARK>
[����]

[Ӧ�ñ���]

[���������]

[��Ҫ�Ĳ�ѯ����]

[ʵ�ַ���]

[����]
</REMARK>
<BEFORERUN>
declare
  Bfiledate  date;
  Efiledate  date;
  StoreCode1 varchar2(10);
  NumC varchar2(20);
begin

  Bfiledate  := '\(1,1)';
  Efiledate  := '\(2,1)';
  StoreCode1 := '\(3,1)';
  NumC := '\(4,1)';

  /*Bfiledate:='2016-09-01';
  Efiledate:='2016-10-31';
  StoreCode1:='40144';*/

  delete from tmp_test2;
  commit;

  insert into tmp_test2
  
    (char13 --����
    ,
     char1 --����
    ,
     char2 --���
    ,
     char3 --����
    ,
     char4 --Ʒ�����
    ,
     char5 --Ʒ��
    ,
     char10 --��Ʒ����
    ,
     char11 --��Ʒ����
    ,
     char12 --��Ʒ������
    ,
     int1 --ʵ����
    ,
     num4 --�ֳܲɱ����
    ,
     num3 --�ɱ����
    ,
     num1 --���۽��
    ,
     date1 --�����
    ,
     char6 --���
    ,
     char7 --״̬
    ,
     char8 --��λ��
    ,
     char9 --��λ
    ,
     date2 --��������
    ,
     date3 --��ʼ����
    ,
     date4, --��������
     char14 ---�۸�����㹫ʽ
     ,char15 --Ʒ��
     --,
     --num5 --�������
     
     )
  --ͳ���
    SELECT STKOUT.CLS,
           STKOUT.NUM NUM,
           CLIENT.CODE storecode,
           CLIENT.NAME storename,
           h4v_goodssort.ascode ascode,
           h4v_goodssort.asname asname,
           goods.code goodscode,
           goods.name goodsname,
           goods.code2 goodscode2,
           sum(STKOUTDTL.QTY) QTY, --ʵ����
           sum(STKOUTDTL.CAMT + STKOUTDTL.CTAX) ziamt, --���ֳܲɱ��� 
           sum(STKOUTDTL.Total) iamt, --���ۣ��ɱ��� 
           --sum((goods.rtlprc) * (STKOUTDTL.QTY)) salamt, Ӫҵ��ۼۻ�䶯���������ţ���Ԫ�գ�Ҫ�󣬸ĳ������ȡֵ��
           sum(STKOUTdtl.CRTOTAL) CRTOTAL, --Ӫҵ�Ϊ�˱�������һ�£�
           
           STKOUT.Ocrdate,
           STKOUT.Filler,
           MODULESTAT.STATNAME STATNAME,
           warehouse.code code2,
           warehouse.name name2,
           trunc(Stkoutlog.time),
           Bfiledate,
           Efiledate,
           wp.whsprcformula,
           goods.brand
           --,To_number(replace(replace(wp.whsprcformula,'RTLPRC',''),'*',''))
    
      FROM STKOUT        STKOUT,
           STKOUTDTL     STKOUTDTL,
           Stkoutlog     Stkoutlog,
           MODULESTAT    MODULESTAT,
           CLIENT         CLIENT,
           GOODS         GOODS,
           h4v_goodssort h4v_goodssort,
           warehouse     warehouse,
           WSPRCGRPGD    wp
    
     WHERE STKOUT.NUM = STKOUTDTL.NUM
       and STKOUT.Cls = STKOUTDTL.Cls
       and STKOUT.CLS = '����'
       and wp.gcode = CLIENT.WSPRCGRP
       and GOODS.Code = wp.GDCode
       and GOODS.Gid = wp.gdgid
       and wp.calcmode = '����ʽ'
       and STKOUT.NUM = Stkoutlog.NUM
       and STKOUT.CLS = Stkoutlog.CLS
       and Stkoutlog.Stat in (700, 720, 740, 320, 340) --���ջ� ״̬
       and STKOUT.STAT = MODULESTAT.NO
       and STKOUT.BILLTO = CLIENT.GID
       and STKOUTDTL.GDGID = GOODS.GID
       and GOODS.GID = h4v_goodssort.gid
          
       and trunc(Stkoutlog.Time) >=Bfiledate 
       and trunc(Stkoutlog.Time)<Efiledate
       and GOODS.Wrh = warehouse.gid
       and (StoreCode1 is null or CLIENT.CODE = StoreCode1)
       and (NumC is null or STKOUT.NUM=NumC)
    
     group by STKOUT.NUM,
              CLIENT.CODE,
              CLIENT.NAME,
              MODULESTAT.STATNAME,
              trunc(Stkoutlog.time),
              h4v_goodssort.ascode,
              h4v_goodssort.asname,
              goods.code,
              goods.name,
              goods.code2,
              STKOUT.Ocrdate,
              STKOUT.Filler,
              warehouse.code,
              warehouse.name,
              wp.whsprcformula,
              STKOUT.CLS,
              goods.brand
    
    union all
    --ͳ�����   
    SELECT STKOUTBCK.CLS,
           STKOUTBCK.NUM NUM,
           CLIENT.CODE storecode,
           CLIENT.NAME storename,
           h4v_goodssort.ascode ascode,
           h4v_goodssort.asname asname,
           goods.code goodscode,
           goods.name goodsname,
           goods.code2 goodscode2,
           -sum(STKOUTBCKDTL.QTY) QTY, --ʵ����
           -sum(STKOUTBCKDTL.CAMT + STKOUTBCKDTL.CTAX) ziamt, --���ֳܲɱ���
           -sum(STKOUTBCKDTL.Total) iamt, --���ۣ��ɱ��� 
           
           -sum(STKOUTBCKdtl.CRTOTAL) CRTOTAL, --Ӫҵ�Ϊ�˱�������һ�£�
           
           STKOUTBCK.Ocrdate,
           STKOUTBCK.Filler,
           MODULESTAT.STATNAME STATNAME,
           warehouse.code code2,
           warehouse.name name2,
           trunc(STKOUTBCKlog.time),
           Bfiledate,
           Efiledate,
           wp.whsprcformula,
           goods.brand
           --,To_number(replace(replace(wp.whsprcformula,'RTLPRC',''),'*',''))
    
      FROM STKOUTBCK     STKOUTBCK,
           STKOUTBCKDTL  STKOUTBCKDTL,
           STKOUTBCKlog  STKOUTBCKlog,
           MODULESTAT    MODULESTAT,
           CLIENT         CLIENT,
           GOODS         GOODS,
           h4v_goodssort h4v_goodssort,
           warehouse     warehouse,
           WSPRCGRPGD    wp
    
     WHERE STKOUTBCK.NUM = STKOUTBCKDTL.NUM
       and STKOUTBCK.Cls = STKOUTBCKDTL.Cls
       and STKOUTBCK.CLS = '������'

       and wp.gcode = CLIENT.WSPRCGRP
       and GOODS.Code = wp.GDCode
       and GOODS.Gid = wp.gdgid
       and wp.calcmode = '����ʽ'
       and STKOUTBCK.NUM = STKOUTBCKlog.NUM
       and STKOUTBCK.CLS = STKOUTBCKlog.CLS
       and STKOUTBCKlog.Stat in (1000, 1020, 1040, 320, 340)
       and STKOUTBCK.STAT = MODULESTAT.NO
       and STKOUTBCK.BILLTO = CLIENT.GID
       and STKOUTBCKDTL.GDGID = GOODS.GID
       and GOODS.GID = h4v_goodssort.gid
          
       and trunc(STKOUTBCKlog.Time) >=Bfiledate 
       and trunc(STKOUTBCKlog.Time) <Efiledate
       and GOODS.Wrh = warehouse.gid
       and (StoreCode1 is null or CLIENT.CODE = StoreCode1)
       and (NumC is null or STKOUTBCK.NUM=NumC)
     group by STKOUTBCK.NUM,
              CLIENT.CODE,
              CLIENT.NAME,
              MODULESTAT.STATNAME,
              trunc(STKOUTBCKlog.time),
              h4v_goodssort.ascode,
              h4v_goodssort.asname,
              goods.code,
              goods.name,
              goods.code2,
              STKOUTBCK.Ocrdate,
              STKOUTBCK.Filler,
              warehouse.code,
              warehouse.name,
              wp.whsprcformula,
              STKOUTBCK.CLS,
           goods.brand
    
  /*  union all
    
    SELECT DirAlc.CLS,
           DirAlc.NUM NUM,
           CLIENT.CODE storecode,
           CLIENT.NAME storename,
           h4v_goodssort.ascode ascode,
           h4v_goodssort.asname asname,
           goods.code goodscode,
           goods.name goodsname,
           goods.code2 goodscode2,
           sum(DirAlcDTL.QTY) QTY, --ʵ����
           sum(DirAlcDTL.CAMT + DirAlcDTL.CTAX) ziamt, --���ֳܲɱ���
           sum(DirAlcDTL.Total) iamt, --���ۣ��ɱ��� 
           --sum((goods.rtlprc) * (STKOUTDTL.QTY)) salamt, Ӫҵ��ۼۻ�䶯���������ţ���Ԫ�գ�Ҫ�󣬸ĳ������ȡֵ��
           sum(DirAlcdtl.RTOTAL) RTOTAL, --Ӫҵ�Ϊ�˱�������һ�£�
           
           DirAlc.Ocrdate,
           DirAlc.Filler,
           MODULESTAT.STATNAME STATNAME,
           warehouse.code code2,
           warehouse.name name2,
           trunc(DirAlclog.time),
           Bfiledate,
           Efiledate,
           wp.whsprcformula,
           goods.brand
           --,To_number(replace(replace(wp.whsprcformula,'RTLPRC',''),'*',''))
    
      FROM DirAlc        DirAlc,
           DirAlcDTL     DirAlcDTL,
           DirAlclog     DirAlclog,
           MODULESTAT    MODULESTAT,
           CLIENT         CLIENT,
           GOODS         GOODS,
           h4v_goodssort h4v_goodssort,
           warehouse     warehouse,
           WSPRCGRPGD    wp
    
     WHERE DirAlc.NUM = DirAlcDTL.NUM
       and DirAlc.Cls = DirAlcDTL.Cls
       and DirAlc.CLS = 'ֱ��������'
       and wp.gcode = CLIENT.WSPRCGRP
       and GOODS.Code = wp.GDCode
       and GOODS.Gid = wp.gdgid
       and wp.calcmode = '����ʽ'
       and DirAlc.NUM = DirAlclog.NUM
       and DirAlc.CLS = DirAlclog.CLS
       and DirAlclog.Stat in (1000, 1020, 1040, 320 ,340)
       and DirAlc.STAT = MODULESTAT.NO
       and DirAlc.RECEIVER = CLIENT.GID
       and DirAlcDTL.GDGID = GOODS.GID
       and GOODS.GID = h4v_goodssort.gid
       and trunc(DirAlclog.Time) >= Bfiledate 
       and trunc(DirAlclog.Time) <Efiledate
       and GOODS.Wrh = warehouse.gid
       and (StoreCode1 is null or CLIENT.CODE = StoreCode1)
       and (NumC is null or DirAlc.NUM=NumC)
     group by DirAlc.NUM,
              CLIENT.CODE,
              CLIENT.NAME,
              MODULESTAT.STATNAME,
              trunc(DirAlclog.time),
              h4v_goodssort.ascode,
              h4v_goodssort.asname,
              goods.code,
              goods.name,
              goods.code2,
              DirAlc.Ocrdate,
              DirAlc.Filler,
              warehouse.code,
              warehouse.name,
              wp.whsprcformula,
              DirAlc.CLS,
           goods.brand


    union all
    
    SELECT DirAlc.CLS,
           DirAlc.NUM NUM,
           CLIENT.CODE storecode,
           CLIENT.NAME storename,
           h4v_goodssort.ascode ascode,
           h4v_goodssort.asname asname,
           goods.code goodscode,
           goods.name goodsname,
           goods.code2 goodscode2,
           sum(DirAlcDTL.QTY) QTY, --ʵ����
           sum(DirAlcDTL.CAMT + DirAlcDTL.CTAX) ziamt, --���ֳܲɱ���
           sum(DirAlcDTL.Total) iamt, --���ۣ��ɱ��� 
           --sum((goods.rtlprc) * (STKOUTDTL.QTY)) salamt, Ӫҵ��ۼۻ�䶯���������ţ���Ԫ�գ�Ҫ�󣬸ĳ������ȡֵ��
           sum(DirAlcdtl.RTOTAL) RTOTAL, --Ӫҵ�Ϊ�˱�������һ�£�
           
           DirAlc.Ocrdate,
           DirAlc.Filler,
           MODULESTAT.STATNAME STATNAME,
           warehouse.code code2,
           warehouse.name name2,
           trunc(DirAlclog.time),
           Bfiledate,
           Efiledate,
           wp.whsprcformula,
           goods.brand
           --,To_number(replace(replace(wp.whsprcformula,'RTLPRC',''),'*',''))
    
      FROM DirAlc        DirAlc,
           DirAlcDTL     DirAlcDTL,
           DirAlclog     DirAlclog,
           MODULESTAT    MODULESTAT,
           CLIENT         CLIENT,
           GOODS         GOODS,
           h4v_goodssort h4v_goodssort,
           warehouse     warehouse,
           WSPRCGRPGD    wp
    
     WHERE DirAlc.NUM = DirAlcDTL.NUM
       and DirAlc.Cls = DirAlcDTL.Cls
       and DirAlc.CLS = '��������'
       and wp.gcode = CLIENT.WSPRCGRP
       and GOODS.Code = wp.GDCode
       and GOODS.Gid = wp.gdgid
       and wp.calcmode = '����ʽ'
       and DirAlc.NUM = DirAlclog.NUM
       and DirAlc.CLS = DirAlclog.CLS
       and DirAlclog.Stat in (700,720,740,320,340)
       and DirAlc.STAT = MODULESTAT.NO
       and DirAlc.RECEIVER = CLIENT.GID
       and DirAlcDTL.GDGID = GOODS.GID
       and GOODS.GID = h4v_goodssort.gid
       and trunc(DirAlclog.Time) >= Bfiledate 
       and trunc(DirAlclog.Time) <Efiledate
       and GOODS.Wrh = warehouse.gid
       and (StoreCode1 is null or CLIENT.CODE = StoreCode1)
       and (NumC is null or DirAlc.NUM=NumC)
     group by DirAlc.NUM,
              CLIENT.CODE,
              CLIENT.NAME,
              MODULESTAT.STATNAME,
              trunc(DirAlclog.time),
              h4v_goodssort.ascode,
              h4v_goodssort.asname,
              goods.code,
              goods.name,
              goods.code2,
              DirAlc.Ocrdate,
              DirAlc.Filler,
              warehouse.code,
              warehouse.name,
             wp.whsprcformula,
              DirAlc.CLS,
           goods.brand		*/
    
    union all
    
    select ALCDIFF.Cls,
           ALCDIFF.Num,
           CLIENT.CODE storecode,
           CLIENT.NAME storename,
           h4v_goodssort.ascode ascode,
           h4v_goodssort.asname asname,
           goods.code goodscode,
           goods.name goodsname,
           goods.code2 goodscode2,
           sum(ALCDIFFDTL.QTY) QTY, --ʵ����
           sum( ALCDIFFDTL.CAMT + ALCDIFFDTL.CTAX) ziamt, --���ֳܲɱ���
           sum(ALCDIFFDTL.Total) iamt, --���ۣ��ɱ��� 
           sum(ALCDIFFdtl.CRTOTAL) CRTOTAL, --Ӫҵ�Ϊ�˱�������һ�£�
           
           ALCDIFF.Ocrdate,
           ALCDIFF.CREATEOPER,
           MODULESTAT.STATNAME STATNAME,
           warehouse.code code2,
           warehouse.name name2,
           trunc(ALCDIFFlog.time),
           Bfiledate,
           Efiledate,
           wp.whsprcformula,
           goods.brand
           --,To_number(replace(replace(wp.whsprcformula,'RTLPRC',''),'*',''))
    
      from ALCDIFF       ALCDIFF,
           ALCDIFFDTL    ALCDIFFDTL,
           ALCDIFFlog    ALCDIFFlog,
           MODULESTAT    MODULESTAT,
           CLIENT         CLIENT,
           GOODS         GOODS,
           h4v_goodssort h4v_goodssort,
           warehouse     warehouse,
           WSPRCGRPGD    wp
    
     WHERE ALCDIFF.NUM = ALCDIFFDTL.NUM
       and ALCDIFF.Cls = ALCDIFFDTL.Cls
       and ALCDIFF.CLS = '��������'
       and wp.gcode = CLIENT.WSPRCGRP
       and GOODS.Code = wp.GDCode
       and GOODS.Gid = wp.gdgid
       and wp.calcmode = '����ʽ'
       and ALCDIFF.NUM = ALCDIFFlog.NUM
       and ALCDIFF.CLS = ALCDIFFlog.CLS
       and ALCDIFFlog.Stat IN (400, 420, 440, 320, 340)
       and ALCDIFF.STAT = MODULESTAT.NO
       and ALCDIFF.BILLTO = CLIENT.GID
       and ALCDIFFDTL.GDGID = GOODS.GID
       and GOODS.GID = h4v_goodssort.gid
       and trunc(ALCDIFFlog.Time) >= Bfiledate 
       and trunc(ALCDIFFlog.Time)<Efiledate
       and GOODS.Wrh = warehouse.gid
       and (StoreCode1 is null or CLIENT.CODE = StoreCode1)
       and (NumC is null or ALCDIFF.Num=NumC)

     group by ALCDIFF.NUM,
              CLIENT.CODE,
              CLIENT.NAME,
              MODULESTAT.STATNAME,
              trunc(ALCDIFFlog.time),
              h4v_goodssort.ascode,
              h4v_goodssort.asname,
              goods.code,
              goods.name,
              goods.code2,
              ALCDIFF.Ocrdate,
              ALCDIFF.CREATEOPER,
              warehouse.code,
              warehouse.name,
             wp.whsprcformula,
              ALCDIFF.CLS,
           goods.brand
    
    ;
  commit;
end;
</BEFORERUN>
<AFTERRUN>
</AFTERRUN>
<TABLELIST>
  <TABLEITEM>
    <TABLE>tmp_test2</TABLE>
    <ALIAS>tmp_test2</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
</TABLELIST>
<JOINLIST>
</JOINLIST>
<COLUMNLIST>
  <FIXEDCOLUMNS>0</FIXEDCOLUMNS>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char13</COLUMN>
    <TITLE>����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char13</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char1</COLUMN>
    <TITLE>����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char2</COLUMN>
    <TITLE>���</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char2</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char3</COLUMN>
    <TITLE>����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char3</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>case when char15='01' then 'ľ������'
     when char15='02' then 'Mumuso Family'
else 'δ֪' end  </COLUMN>
    <TITLE>Ʒ��</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char15</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char4</COLUMN>
    <TITLE>Ʒ�����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char4</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char5</COLUMN>
    <TITLE>Ʒ��</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char5</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>int1</COLUMN>
    <TITLE>ʵ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>int1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>0</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>num4</COLUMN>
    <TITLE>�ֳܲɱ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>num4</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>0.00</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>num3</COLUMN>
    <TITLE>�ͻ�������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>num3</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>0.00</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>num1</COLUMN>
    <TITLE>���۽��</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>num1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>0.00</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char14</COLUMN>
    <TITLE>�����۹�ʽ</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char14</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>num5</COLUMN>
    <TITLE>�������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>num5</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>,0.0000</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>sum(num1*num5)</COLUMN>
    <TITLE>������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>Nx</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>,0.0000</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>date1</COLUMN>
    <TITLE>�����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>date1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>yyyy.MM.dd</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char6</COLUMN>
    <TITLE>���</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char6</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char7</COLUMN>
    <TITLE>״̬</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char7</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char8</COLUMN>
    <TITLE>��λ��</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char8</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>char9</COLUMN>
    <TITLE>��λ</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>char9</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>date2</COLUMN>
    <TITLE>��������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>date2</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>yyyy.MM.dd</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>date3</COLUMN>
    <TITLE>��ʼ����</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>date3</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>yyyy.MM.dd</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>date4</COLUMN>
    <TITLE>��������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>date4</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>yyyy.MM.dd</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
</COLUMNLIST>
<COLUMNWIDTH>
  <COLUMNWIDTHITEM>32</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>92</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>44</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>44</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>82</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>53</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>98</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>163</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>94</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>98</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>68</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>68</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>44</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>44</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>44</COLUMNWIDTHITEM>
</COLUMNWIDTH>
<GROUPLIST>
  <GROUPITEM>
    <COLUMN>char13</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char1</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char2</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char3</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>case when char15='01' then 'ľ������'
     when char15='02' then 'Mumuso Family'
else 'δ֪' end  </COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char4</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char5</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char14</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>date1</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char6</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char7</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char8</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>char9</COLUMN>
  </GROUPITEM>
</GROUPLIST>
<ORDERLIST>
</ORDERLIST>
<CRITERIALIST>
  <WIDTHLIST>
  </WIDTHLIST>
  <CRITERIAITEM>
    <LEFT>date2</LEFT>
    <OPERATOR>>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2017.12.01</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>�³�</DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>date3</LEFT>
    <OPERATOR><</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2017.12.15</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>����</DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>char2</LEFT>
    <OPERATOR>IN</OPERATOR>
    <RIGHT>
      <RIGHTITEM>88888</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>char1</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
</CRITERIALIST>
<CRITERIAWIDTH>
  <CRITERIAWIDTHITEM>100</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>100</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>64</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>168</CRITERIAWIDTHITEM>
</CRITERIAWIDTH>
<SG>
  <LINE>
  </LINE>
  <LINE>
    <SGLINEITEM>���� 1��</SGLINEITEM>
    <SGLINEITEM>2017.12.01</SGLINEITEM>
    <SGLINEITEM>2017.12.15</SGLINEITEM>
    <SGLINEITEM>88888</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 2��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 3��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 4��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
  </LINE>
</SG>
<CHECKLIST>
  <CAPTION>
  </CAPTION>
  <EXPRESSION>
  </EXPRESSION>
  <CHECKED>
  </CHECKED>
  <ANDOR> and </ANDOR>
</CHECKLIST>
<UNIONLIST>
</UNIONLIST>
<NCRITERIAS>
  <NUMOFNEXTQRY>0</NUMOFNEXTQRY>
</NCRITERIAS>
<MULTIQUERIES>
  <NUMOFMULTIQRY>0</NUMOFMULTIQRY>
</MULTIQUERIES>
<FUNCTIONLIST>
</FUNCTIONLIST>
<DXDBGRIDITEM>
  <DXLOADMETHOD>FALSE</DXLOADMETHOD>
  <DXSHOWGROUP>FALSE</DXSHOWGROUP>
  <DXSHOWFOOTER>TRUE</DXSHOWFOOTER>
  <DXSHOWSUMMARY>FALSE</DXSHOWSUMMARY>
  <DXSHOWPREVIEW>FALSE</DXSHOWPREVIEW>
  <DXSHOWFILTER>FALSE</DXSHOWFILTER>
  <DXPREVIEWFIELD></DXPREVIEWFIELD>
  <DXCOLORODDROW>-2147483643</DXCOLORODDROW>
  <DXCOLOREVENROW>-2147483643</DXCOLOREVENROW>
  <DXFILTERNAME></DXFILTERNAME>
  <DXFILTERTYPE></DXFILTERTYPE>
  <DXFILTERLIST>
  </DXFILTERLIST>
  <DXSHOWGRIDLINE>1</DXSHOWGRIDLINE>
</DXDBGRIDITEM>
</SQLQUERY>
<SQLREPORT>
<RPTTITLE></RPTTITLE>
<RPTGROUPCOUNT>0</RPTGROUPCOUNT>
<RPTGROUPLIST>
</RPTGROUPLIST>
<RPTCOLUMNCOUNT>0</RPTCOLUMNCOUNT>
<RPTCOLUMNWIDTHLIST>
</RPTCOLUMNWIDTHLIST>
<RPTLEFTMARGIN>20</RPTLEFTMARGIN>
<RPTORIENTATION>0</RPTORIENTATION>
<RPTCOLUMNS>1</RPTCOLUMNS>
<RPTHEADERLEVEL>0</RPTHEADERLEVEL>
<RPTPRINTCRITERIA>TRUE</RPTPRINTCRITERIA>
<RPTVERSION></RPTVERSION>
<RPTNOTE></RPTNOTE>
<RPTFONTSIZE>10</RPTFONTSIZE>
<RPTLINEHEIGHT>����</RPTLINEHEIGHT>
<RPTPAGEHEIGHT>66</RPTPAGEHEIGHT>
<RPTPAGEWIDTH>80</RPTPAGEWIDTH>
<RPTTITLETYPE>0</RPTTITLETYPE>
<RPTCURREPORT></RPTCURREPORT>
<RPTREPORTLIST>
</RPTREPORTLIST>
</SQLREPORT>

