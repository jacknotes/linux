<VERSION>4.1.0</VERSION>
<SQLQUERY>
<REMARK>
[����]
��������ѯ������Ӧ�̻��ܣ�

[Ӧ�ñ���]
�ñ������ڹ�Ӧ�̾���������Ĳο����ݡ�

[���������]
�����ڼ�Ľ������Ѿ����˽�ʣ������
���н������ȡֵ��һ��ʱ����ڵĽ��˻����
�Ѷ��˽����е��Ѹ��˵Ķ��˽��
ʣ������ܲ����ŵ�Ŀ������ * ��Ʒ�ĺ�ͬ����

[��Ҫ�Ĳ�ѯ����]

[ʵ�ַ���]

[����]
begin
execute immediate 'Create Global Temporary Table H4RTMP_STKIN(
BILLTOCOE   VARCHAR2(10),
  BILLTONAME  VARCHAR2(80),
  VENDORCOE   VARCHAR2(10),
  VENDORNAME  VARCHAR2(80),
  STORECODE   VARCHAR2(100),
  STORENAME   VARCHAR2(100),
  AREACODE    VARCHAR2(100),
  AREANAME    VARCHAR2(200),
  DIRALCSTAT  VARCHAR2(100),
  LOGSTATE    INTEGER,
  STKINTOTAL     NUMBER(24,2),
  STKINTAX       NUMBER(24,2),
  STKINQSINTOTAL   NUMBER,  -- ȥ˰
  
  STKBCKTOTAL    NUMBER(24,2),
  STKBCKTAX      NUMBER(24,2),
  STKBCKQSTOTAL   NUMBER,
  
  SUMSTKTOTAL    NUMBER,   
  SUMSTKTAX      NUMBER,
  SUMSTKQSTOTAL  NUMBER,   
  
  DIRINTOTAL     NUMBER(24,2),
  DIRINTAX       NUMBER(24,2),
  DIRINQSTOTAL   NUMBER,
   
  DIRBCKTOTAL    NUMBER(24,2),
  DIRBCKTAX      NUMBER(24,2),
  DIRBCKQSTOTAL  NUMBER,
  
  SUMDIRTOTAL    NUMBER,
  SUMDIRTAX      NUMBER,
  SUMDIRQSTOTAL  NUMBER,
  
  SUMTOTAL      NUMBER,
  SUMQSTOTAL    NUMBER,
  
  PAYMODE     VARCHAR2(20),
  IVCREGED    INTEGER,
  IVCPAY      INTEGER,
  CTBREGED    INTEGER,
  TIME        DATE,
  FLAG        VARCHAR2(100),
  NUM         VARCHAR2(40),
  SRCORDNUM   VARCHAR2(40),
  SRCNUM      VARCHAR2(40),
  NOTE        VARCHAR2(255),
  CLS         VARCHAR2(50)
) On commit preserve Rows';
end;
/

exec hdcreatesynonym('H4RTMP_STKIN');
exec granttoqryrole('H4RTMP_STKIN');

Create Global Temporary Table H4RTMP_STKIN2(
BILLTOCOE   VARCHAR2(10),
  BILLTONAME  VARCHAR2(80),
  VENDORCOE   VARCHAR2(10),
  VENDORNAME  VARCHAR2(80),
  STORECODE   VARCHAR2(100),
  STORENAME   VARCHAR2(100),
  AREACODE    VARCHAR2(100),
  AREANAME    VARCHAR2(200),
  DIRALCSTAT  VARCHAR2(100),
  LOGSTATE    INTEGER,
  STKINTOTAL     NUMBER(24,2),
  STKINTAX       NUMBER(24,2),
  STKINQSINTOTAL   NUMBER,  -- ȥ˰
  STKBCKTOTAL    NUMBER(24,2),
  STKBCKTAX      NUMBER(24,2),
  STKBCKQSTOTAL   NUMBER,
  SUMSTKTOTAL    NUMBER,   
  SUMSTKTAX      NUMBER,
  SUMSTKQSTOTAL  NUMBER,   
  DIRINTOTAL     NUMBER(24,2),
  DIRINTAX       NUMBER(24,2),
  DIRINQSTOTAL   NUMBER,
  DIRBCKTOTAL    NUMBER(24,2),
  DIRBCKTAX      NUMBER(24,2),
  DIRBCKQSTOTAL  NUMBER,
  SUMDIRTOTAL    NUMBER,
  SUMDIRTAX      NUMBER,
  SUMDIRQSTOTAL  NUMBER,
  SUMTOTAL      NUMBER,
  SUMQSTOTAL    NUMBER,
  PAYMODE     VARCHAR2(20),
  IVCREGED    INTEGER,
  IVCPAY      INTEGER,
  CTBREGED    INTEGER,
  TIME        DATE,
  FLAG        VARCHAR2(100),
  NUM         VARCHAR2(40),
  SRCORDNUM   VARCHAR2(40),
  SRCNUM      VARCHAR2(40),
  NOTE        VARCHAR2(255),
  CLS         VARCHAR2(50)
) 
on commit preserve rows;
grant insert,delete,update on H4RTMP_STKIN2 to ROLE_HDAPP;
grant insert,delete,update on H4RTMP_STKIN2 to ROLE_HDQRY;
/
exec hdcreatesynonym('H4RTMP_STKIN2');
exec granttoqryrole('H4RTMP_STKIN2');
</REMARK>
<BEFORERUN>
DECLARE
VBDATE  DATE;
VEDATE  DATE;
VFLAG   VARCHAR2(10);
vvdrcode varchar2(20);

BEGIN
  VBDATE := '\(1,1)';
  VEDATE := '\(2,1)';
  VFLAG  := '\(3,1)';
  vvdrcode  := '\(4,1)';
  
  DELETE H4RTMP_STKIN ;
  COMMIT;
  IF VFLAG = '����������' THEN   -- ȡLOG����
    BEGIN
     -- ��Ӫ��
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
     SELECT  D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             M.STATNAME ,
             LOG.STAT ,
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,
             0,
             0,
             0,
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,
             0,
             0,
             0,            
             0,
             0,
             0,
             0 ,
             0 ,
             0 ,
             D.TOTAL,
             D.TOTAL - D.TAX,
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(LOG.TIME) TIME,
             VFLAG
        FROM STKIN     D,
             STKINLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = '��Ӫ��'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (1000) 
         AND D.STAT IN (1000,300)
         AND M.NO = D.STAT   
		 and (vvendor.code = vvdrcode or vvdrcode is null)
         AND TRUNC(LOG.TIME) >= VBDATE
         AND TRUNC(LOG.TIME) <  VEDATE ;  
                
     -- ��Ӫ����
      INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
     SELECT  D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             M.STATNAME ,
             LOG.STAT ,
             0,
             0,
             0,
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,             
             D.TOTAL*(-1),
             D.TAX*(-1) ,
             (D.TOTAL - D.TAX)*(-1) ,
             0,
             0,
             0,            
             0,
             0,
             0,
             0 ,
             0 ,
             0 ,
             D.TOTAL*(-1),
             (D.TOTAL - D.TAX)*(-1),
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(LOG.TIME) TIME,
             VFLAG
        FROM STKINBCK     D,  
             STKINBCKLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = '��Ӫ����'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (700) 
         AND D.STAT IN (700,300)
         AND M.NO = D.STAT     
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(LOG.TIME) >= VBDATE
         AND TRUNC(LOG.TIME) <  VEDATE ;         
 
     -- ֱ���
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,STORECODE,STORENAME,AREACODE,AREANAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
     SELECT  D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             S.CODE,
             S.NAME,
             A.CODE,
             A.NAME,
             M.STATNAME ,
             LOG.STAT ,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,            
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,
             0,
             0,
             0,
             D.TOTAL ,
             D.TAX ,
             D.TOTAL - D.TAX ,
             D.TOTAL,
             D.TOTAL - D.TAX,
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(LOG.TIME) TIME,
             VFLAG
        FROM DIRALC    D,
             DIRALCLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M,
             STORE     S,
             AREA      A
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = 'ֱ���'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (1000)
         AND D.STAT IN (1000,300) 
         AND M.NO = D.STAT  
         AND D.RECEIVER = S.GID
         AND S.AREA = A.CODE            
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(LOG.TIME) >= VBDATE
         AND TRUNC(LOG.TIME) <  VEDATE ;

      -- ֱ�����          
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,STORECODE,STORENAME,AREACODE,AREANAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
      SELECT D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             S.CODE,
             S.NAME,
             A.CODE,
             A.NAME,
             M.STATNAME ,
             LOG.STAT ,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,   
             0,
             0,
             0,         
             D.TOTAL ,
             D.TAX ,
             D.TOTAL - D.TAX,
             D.TOTAL*(-1),
             D.TAX*(-1),
             (D.TOTAL - D.TAX)*(-1),
             D.TOTAL*(-1),
             (D.TOTAL - D.TAX)*(-1),
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(LOG.TIME) TIME,
             VFLAG
        FROM DIRALC    D,
             DIRALCLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M,
             STORE     S,
             AREA      A
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = 'ֱ�����'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (700) 
         AND D.STAT IN (700,300)
         AND M.NO = D.STAT
         AND D.RECEIVER = S.GID
         AND S.AREA = A.CODE      
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(LOG.TIME) >= VBDATE
         AND TRUNC(LOG.TIME) <  VEDATE   ;

		BEGIN
		UPDATE H4RTMP_STKIN2 SET CTBREGED = 1
		where (num,CLS) in(select DTL.SRCNUM,DTL.SCLS from PurchaseBySaleCTB v, PurchaseBySaleCTBDTL2 dtl
						 where v.num = dtl.num and v.stat IN(600));
	   -- COMMIT;  
		END;                                                      
		END;           
    ELSE
       BEGIN
     -- ��Ӫ��
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
     SELECT  D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             M.STATNAME ,
             LOG.STAT ,
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,
             0,
             0,
             0,
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,
             0,
             0,
             0,            
             0,
             0,
             0,
             0 ,
             0 ,
             0 ,
             D.TOTAL,
             D.TOTAL - D.TAX,
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(D.OCRDATE) TIME,
             VFLAG
        FROM STKIN     D,
             STKINLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = '��Ӫ��'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (1000) 
         AND D.STAT IN (1000,300)
         AND M.NO = D.STAT         
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(D.OCRDATE) >= VBDATE
         AND TRUNC(D.OCRDATE) <  VEDATE  ; 
                
     -- ��Ӫ����
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
     SELECT  D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             M.STATNAME ,
             LOG.STAT ,
             0,
             0,
             0,
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,             
             D.TOTAL*(-1),
             D.TAX*(-1) ,
             (D.TOTAL - D.TAX)*(-1) ,
             0,
             0,
             0,            
             0,
             0,
             0,
             0 ,
             0 ,
             0 ,
             D.TOTAL*(-1),
             (D.TOTAL - D.TAX)*(-1),
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(D.OCRDATE) ,
             VFLAG
        FROM STKINBCK     D,
             STKINBCKLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = '��Ӫ����'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (700) 
         AND D.STAT IN (700,300)
         AND M.NO = D.STAT           
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(D.OCRDATE) >= VBDATE
         AND TRUNC(D.OCRDATE) <  VEDATE   ;       
 
     -- ֱ���
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,STORECODE,STORENAME,AREACODE,AREANAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
     SELECT  D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             S.CODE,
             S.NAME,
             A.CODE,
             A.NAME,
             M.STATNAME ,
             LOG.STAT ,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,            
             D.TOTAL,
             D.TAX ,
             D.TOTAL - D.TAX ,
             0,
             0,
             0,
             D.TOTAL ,
             D.TAX ,
             D.TOTAL - D.TAX ,
             D.TOTAL,
             D.TOTAL - D.TAX,
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(D.OCRDATE) TIME,
             VFLAG
        FROM DIRALC    D,
             DIRALCLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M,
             STORE     S,
             AREA      A
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = 'ֱ���'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (1000)
         AND D.STAT IN (1000,300) 
         AND M.NO = D.STAT   
         AND D.RECEIVER = S.GID
         AND S.AREA = A.CODE               
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(D.OCRDATE) >= VBDATE
         AND TRUNC(D.OCRDATE) <  VEDATE   ;

      -- ֱ�����          
     INSERT INTO H4RTMP_STKIN2(NUM,CLS,BILLTOCOE,BILLTONAME,VENDORCOE,VENDORNAME,STORECODE,STORENAME,AREACODE,AREANAME,DIRALCSTAT,LOGSTATE,STKINTOTAL,STKINTAX,
     STKINQSINTOTAL,STKBCKTOTAL,STKBCKTAX,STKBCKQSTOTAL,SUMSTKTOTAL,SUMSTKTAX,SUMSTKQSTOTAL,DIRINTOTAL,DIRINTAX,
     DIRINQSTOTAL,DIRBCKTOTAL,DIRBCKTAX,DIRBCKQSTOTAL,SUMDIRTOTAL,SUMDIRTAX,SUMDIRQSTOTAL,SUMTOTAL,SUMQSTOTAL,
     PAYMODE,IVCREGED,IVCPAY,CTBREGED,TIME,FLAG)
      SELECT D.NUM,
             D.CLS,
             VBILLTO.CODE ,
             VBILLTO.NAME ,
             VVENDOR.CODE ,
             VVENDOR.NAME ,
             S.CODE,
             S.NAME,
             A.CODE,
             A.NAME,
             M.STATNAME ,
             LOG.STAT ,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,
             0,   
             0,
             0,
             0,         
             D.TOTAL ,
             D.TAX ,
             D.TOTAL - D.TAX,
             D.TOTAL*(-1),
             D.TAX*(-1),
             (D.TOTAL - D.TAX)*(-1),
             D.TOTAL*(-1),
             (D.TOTAL - D.TAX)*(-1),
             D.PAYMODE,
             D.IVCREGED,
             D.IVCPAY,
             0,
             TRUNC(D.OCRDATE) TIME,
             VFLAG
        FROM DIRALC    D,
             DIRALCLOG LOG,
             VENDOR    VBILLTO,
             VENDOR    VVENDOR,
             MODULESTAT M,
             STORE     S,
             AREA      A
       WHERE D.NUM = LOG.NUM
         AND D.CLS = LOG.CLS
         AND D.CLS = 'ֱ�����'
         AND D.BILLTO = VBILLTO.GID
         AND D.VENDOR = VVENDOR.GID
         AND LOG.STAT in (700) 
         AND D.STAT IN (700,300)
         AND M.NO = D.STAT 
         AND D.RECEIVER = S.GID
         AND S.AREA = A.CODE      
		and (vvendor.code = vvdrcode or vvdrcode is null)		 
         AND TRUNC(D.OCRDATE) >= VBDATE
         AND TRUNC(D.OCRDATE) <  VEDATE   ;             
    
        BEGIN
    UPDATE H4RTMP_STKIN2 SET CTBREGED = 1
    where (num,CLS) in(select DTL.SRCNUM,DTL.SCLS from PurchaseBySaleCTB v, PurchaseBySaleCTBDTL2 dtl
                     where v.num = dtl.num and v.stat IN(600));
   -- COMMIT;  
    END;    
    END;      
 END IF;

	--- �ܽ��˻����
	insert into h4rtmp_stkin(billtocoe, billtoname, sumtotal, time, flag)
	SELECT  H4RTMP_STKIN2.BILLTOCOE BILLTOCOE, H4RTMP_STKIN2.BILLTONAME BILLTONAME, SUM(H4RTMP_STKIN2.SUMTOTAL) SUMTOTAL, vbdate, vflag
	FROM H4RTMP_STKIN2 H4RTMP_STKIN2
	GROUP BY H4RTMP_STKIN2.BILLTOCOE, H4RTMP_STKIN2.BILLTONAME
	ORDER BY BILLTOCOE ASC;
	
	--- �ѽ�����
	insert into h4rtmp_stkin(billtocoe, billtoname, stkintotal, time, flag)
	select v.code, v.name, sum(mst.total), vbdate, vflag
	from purchasebysalectb mst, vendorh v
	where mst.billto = v.gid
		and (v.code = vvdrcode or vvdrcode is null)
		and mst.stat in (600)
	group by v.code, v.name;
	
	---ʣ������
	insert into h4rtmp_stkin(billtocoe, billtoname, stkbcktotal, time, flag)
	SELECT  VENDORH.code, VENDORH.name, 
		SUM( ( BUSINVS.QTY + BUSINVS.DSPQTY + BUSINVS.ALCQTY + BUSINVS.BCKQTY + BUSINVS.RSVQTY + BUSINVS.RSVALCQTY ) *   GOODS.CNTINPRC ) Column111, vbdate, vflag
	FROM GOODS GOODS, WAREHOUSE WAREHOUSE, STORE STORE, BUSINVS BUSINVS, VENDORH VENDORH
	WHERE ((BUSINVS.GDGID = GOODS.GID)
		and  (BUSINVS.STORE = STORE.GID)
		and  (BUSINVS.WRH = WAREHOUSE.GID)
		and  (GOODS.VDRGID = VENDORH.GID) )
		and (VENDORH.code = vvdrcode or vvdrcode is null)		 
	GROUP BY VENDORH.code, VENDORH.name;
	
END;
</BEFORERUN>
<AFTERRUN>
</AFTERRUN>
<TABLELIST>
  <TABLEITEM>
    <TABLE>H4RTMP_STKIN</TABLE>
    <ALIAS>H4RTMP_STKIN</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
</TABLELIST>
<JOINLIST>
</JOINLIST>
<COLUMNLIST>
  <FIXEDCOLUMNS>3</FIXEDCOLUMNS>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_STKIN.BILLTOCOE</COLUMN>
    <TITLE>���㹩Ӧ�̴���</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>BILLTOCOE</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_STKIN.BILLTONAME</COLUMN>
    <TITLE>���㹩Ӧ������</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>BILLTONAME</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_STKIN.DIRALCSTAT</COLUMN>
    <TITLE>����״̬</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>DIRALCSTAT</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>nvl(H4RTMP_STKIN.SUMTOTAL, 0)</COLUMN>
    <TITLE>��˰�ܽ������</TITLE>
    <FIELDTYPE>6</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>SUMTOTAL</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>H4RTMP_STKIN.SUMQSTOTAL</COLUMN>
    <TITLE>ȥ˰�ܽ������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>SUMQSTOTAL</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>H4RTMP_STKIN.SUMTOTAL-H4RTMP_STKIN.SUMQSTOTAL</COLUMN>
    <TITLE>��˰��</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>SUMTAX</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_STKIN.TIME</COLUMN>
    <TITLE>����/��������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>TIME</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT>yyyy.mm.dd</CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_STKIN.FLAG</COLUMN>
    <TITLE>��������</TITLE>
    <FIELDTYPE>0</FIELDTYPE>
    <VISIBLE>FALSE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>FALSE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>FLAG</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>nvl(H4RTMP_STKIN.stkintotal, 0)</COLUMN>
    <TITLE>�Ѷ��˽��</TITLE>
    <FIELDTYPE>6</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>stkintotal</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>nvl(H4RTMP_STKIN.stkbcktotal, 0)</COLUMN>
    <TITLE>ʣ������</TITLE>
    <FIELDTYPE>6</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>stkbcktotal</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION>SUM</AGGREGATION>
    <COLUMN>nvl(H4RTMP_STKIN.SUMTOTAL, 0) - nvl(H4RTMP_STKIN.stkintotal, 0) - nvl(H4RTMP_STKIN.stkbcktotal, 0)</COLUMN>
    <TITLE>��������</TITLE>
    <FIELDTYPE>6</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION>SUM</GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>tocheck</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
</COLUMNLIST>
<COLUMNWIDTH>
  <COLUMNWIDTHITEM>66</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>200</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>126</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>106</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>121</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>126</COLUMNWIDTHITEM>
</COLUMNWIDTH>
<GROUPLIST>
  <GROUPITEM>
    <COLUMN>H4RTMP_STKIN.BILLTOCOE</COLUMN>
  </GROUPITEM>
  <GROUPITEM>
    <COLUMN>H4RTMP_STKIN.BILLTONAME</COLUMN>
  </GROUPITEM>
</GROUPLIST>
<ORDERLIST>
  <ORDERITEM>
    <COLUMN>���㹩Ӧ�̴���</COLUMN>
    <ORDER>ASC</ORDER>
  </ORDERITEM>
</ORDERLIST>
<CRITERIALIST>
  <WIDTHLIST>
  </WIDTHLIST>
  <CRITERIAITEM>
    <LEFT>H4RTMP_STKIN.TIME</LEFT>
    <OPERATOR>>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2010.05.01</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>H4RTMP_STKIN.TIME</LEFT>
    <OPERATOR><</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2010.08.12</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>����</DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>H4RTMP_STKIN.FLAG</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM>����������</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
      <PICKNAMEITEM>����������</PICKNAMEITEM>
      <PICKNAMEITEM>����������</PICKNAMEITEM>
    </PICKNAME>
    <PICKVALUE>
      <PICKVALUEITEM>����������</PICKVALUEITEM>
      <PICKVALUEITEM>����������</PICKVALUEITEM>
    </PICKVALUE>
    <DEFAULTVALUE>����������</DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>H4RTMP_STKIN.BILLTOCOE</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>H4RTMP_STKIN.BILLTONAME</LEFT>
    <OPERATOR>LIKE</OPERATOR>
    <RIGHT>
      <RIGHTITEM>%%</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>%%</DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
</CRITERIALIST>
<CRITERIAWIDTH>
  <CRITERIAWIDTHITEM>130</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>106</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>90</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>112</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>124</CRITERIAWIDTHITEM>
</CRITERIAWIDTH>
<SG>
  <LINE>
  </LINE>
  <LINE>
    <SGLINEITEM>���� 1��</SGLINEITEM>
    <SGLINEITEM>2010.05.01</SGLINEITEM>
    <SGLINEITEM>2010.08.12</SGLINEITEM>
    <SGLINEITEM>����������</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM>%%</SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 2��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 3��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 4��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
  </LINE>
</SG>
<CHECKLIST>
  <CAPTION>
  </CAPTION>
  <EXPRESSION>
  </EXPRESSION>
  <CHECKED>
  </CHECKED>
  <ANDOR> and </ANDOR>
</CHECKLIST>
<UNIONLIST>
</UNIONLIST>
<NCRITERIAS>
  <NUMOFNEXTQRY>0</NUMOFNEXTQRY>
</NCRITERIAS>
<MULTIQUERIES>
  <NUMOFMULTIQRY>0</NUMOFMULTIQRY>
</MULTIQUERIES>
<FUNCTIONLIST>
</FUNCTIONLIST>
<DXDBGRIDITEM>
  <DXLOADMETHOD>FALSE</DXLOADMETHOD>
  <DXSHOWGROUP>FALSE</DXSHOWGROUP>
  <DXSHOWFOOTER>TRUE</DXSHOWFOOTER>
  <DXSHOWSUMMARY>FALSE</DXSHOWSUMMARY>
  <DXSHOWPREVIEW>FALSE</DXSHOWPREVIEW>
  <DXSHOWFILTER>FALSE</DXSHOWFILTER>
  <DXPREVIEWFIELD></DXPREVIEWFIELD>
  <DXCOLORODDROW>-2147483643</DXCOLORODDROW>
  <DXCOLOREVENROW>-2147483643</DXCOLOREVENROW>
  <DXFILTERNAME></DXFILTERNAME>
  <DXFILTERLIST>
  </DXFILTERLIST>
  <DXSHOWGRIDLINE>1</DXSHOWGRIDLINE>
</DXDBGRIDITEM>
</SQLQUERY>
<SQLREPORT>
<RPTTITLE></RPTTITLE>
<RPTGROUPCOUNT>0</RPTGROUPCOUNT>
<RPTGROUPLIST>
</RPTGROUPLIST>
<RPTCOLUMNCOUNT>0</RPTCOLUMNCOUNT>
<RPTCOLUMNWIDTHLIST>
</RPTCOLUMNWIDTHLIST>
<RPTLEFTMARGIN>20</RPTLEFTMARGIN>
<RPTORIENTATION>0</RPTORIENTATION>
<RPTCOLUMNS>1</RPTCOLUMNS>
<RPTHEADERLEVEL>0</RPTHEADERLEVEL>
<RPTPRINTCRITERIA>TRUE</RPTPRINTCRITERIA>
<RPTVERSION></RPTVERSION>
<RPTNOTE></RPTNOTE>
<RPTFONTSIZE>10</RPTFONTSIZE>
<RPTLINEHEIGHT>����</RPTLINEHEIGHT>
<RPTPAGEHEIGHT>66</RPTPAGEHEIGHT>
<RPTPAGEWIDTH>80</RPTPAGEWIDTH>
<RPTTITLETYPE>0</RPTTITLETYPE>
<RPTCURREPORT></RPTCURREPORT>
<RPTREPORTLIST>
</RPTREPORTLIST>
</SQLREPORT>

