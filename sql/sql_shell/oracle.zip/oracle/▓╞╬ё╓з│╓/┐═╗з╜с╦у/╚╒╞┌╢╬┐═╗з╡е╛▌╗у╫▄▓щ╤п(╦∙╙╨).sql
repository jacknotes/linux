<VERSION>4.1.0</VERSION>
<SQLQUERY>
<REMARK>
[����]

[Ӧ�ñ���]

[���������]

[��Ҫ�Ĳ�ѯ����]

[ʵ�ַ���]

[����]
</REMARK>
<BEFORERUN>
declare
vbegdate date;
venddate date;
vvdrcode varchar2(50);
begin
/*
alter table H4RTMP_VDRDocuments add rcvreg int;
alter table H4RTMP_VDRDocuments add ivcreg int;
alter table H4RTMP_VDRDocuments add payreg int;
*/

  vbegdate := to_date('\(1,1)','yyyy.mm.dd');
  venddate := to_date('\(2,1)','yyyy.mm.dd');
  vvdrcode := trim('\(3,1)')||'%';

     --����
    insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat,ivcreg,payreg)
    select s.client,'����','����',s.num,l.stat,trunc(l.time),s.total,s.stat,s.ivcreg,s.payreg
    from stkout s , stkoutlog l
    where s.num=l.num
      and s.cls=l.cls
      and s.cls = '����'
      and l.stat in (700, 720, 740, 320 ,340)
      and l.time < venddate + 1
      and l.time >= vbegdate
      and s.client in (select gid from clienth where code like vvdrcode );

    --����
    insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat,ivcreg,payreg)
    select s.Store,'��������','��������',s.num,l.stat,trunc(l.time),s.total,s.stat,s.ivcreg,s.payreg
    from ALCDIFF s , ALCDIFFlog l
    where s.num=l.num
      and s.cls=l.cls
      and s.cls = '��������'
      and l.stat in (100,120,140,320 ,340)
      and l.time < venddate + 1
      and l.time >= vbegdate
      and s.Store in (select gid from clienth where code like vvdrcode );

     --�˻����
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat,ivcreg,payreg)
     select s.client,'������','������',s.num,l.stat,trunc(l.time),s.total,s.stat,s.ivcreg,s.payreg
     from StkOutBck s,stkoutbcklog l
     where s.num=l.num
       and s.cls=l.cls
       and s.cls='������'
       and l.stat in (320,340,1000,1020,1040)
      and l.time < venddate + 1
      and l.time >= vbegdate
      and s.client in (select gid from clienth where code like vvdrcode );

     --
     update H4RTMP_VDRDocuments set rcvreg = 1 where (num,cls) in (select d.srcnum,decode(d.srccls,'����','����','��������','��������','������','������',d.srccls)
                                                                    from CLIENTCHKRCV m,CLIENTCHKRCVDTL d
                                                                   where m.num = d.num
                                                                     and m.stat in (0,100,1700,300));
     update H4RTMP_VDRDocuments set rcvreg = 0 where rcvreg is null and cls in ('����','��������','������');
     update H4RTMP_VDRDocuments set rcvreg = 0 where ivcreg is null and cls in ('����','��������','������');
     update H4RTMP_VDRDocuments set rcvreg = 0 where payreg is null and cls in ('����','��������','������');
     --
     --���ջ���
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     select a.vgid,'�տ�Ǽ�','����',a.num,l.stat,trunc(l.time),a.svipaytotal+a.chkrcvtotal,a.stat
     from cpay a ,cpayLOG l
     where a.num = l.num
       and l.stat in (500,520,540)
       and l.time< venddate + 1
       and l.time>= vbegdate
       and A.vgid in (select gid from clienth where code like vvdrcode );

     --���÷���
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     SELECT c.CLIENT,'�ͻ����õ�',d.finname,c.num,l.stat,trunc(l.time),c.shouldamt*c.paydirect*-1,c.stat
     FROM CLIENTCHGBOOK c,CLIENTCHGBOOKlog l,CLTCHGDEF d
     WHERE c.num =l.num and c.chgcode = D.CODE 
      and l.STAT in (100,120,140,320,340)
      and l.time< venddate + 1
      and l.time>= vbegdate
      and c.CLIENT in (select gid from clienth where code like vvdrcode );

     --���ø���
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     select a.client,'�ͻ��տ','�ͻ��տ',a.num,l.stat,trunc(l.time),a.total,a.stat
       from ClientPay a,ClientPaylog l
      where a.num =l.num
      and a.cls = l.cls
      and l.stat in (900,920,940,320,340)
      and l.time< venddate + 1
      and l.time>= vbegdate
      and a.client in (select gid from clienth where code like vvdrcode );

     --���õֿ�-����ֿ�
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     select a.vgid,'�տ�Ǽ�','����',a.num,l.stat,trunc(l.time),a.feepaytotal,a.stat
     from cpay a ,cpayLOG l
     where a.num = l.num
       and l.stat in (500,520,540)
       and l.time< venddate + 1
       and l.time>= vbegdate
       and A.vgid in (select gid from clienth where code like vvdrcode);
     --���õֿ�-�����ֿۣ�����

     --Ԥ���տ�
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     SELECT a.client,'Ԥ���տ','Ԥ���տ',a.num,decode(l.stat,300,1800,l.stat),trunc(l.time),a.TOTAL,a.stat
     FROM CLTPREPAY a,CLTPREPAYlog l
     WHERE a.num = l.num
       and decode(l.stat,300,1800,l.stat) in (1800,1820,1840,320,340)
       and l.time< venddate + 1
       and l.time>= vbegdate
       and A.client in (select gid from clienth where code like vvdrcode);

     --Ԥ�ջ���
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     SELECT a.client,'Ԥ�ջ��','Ԥ�ջ��',a.num,l.stat,trunc(l.time),a.TOTAL,a.stat
     FROM CLTPREPAYRTN a,CLTPREPAYRTNlog l
     WHERE a.num = l.num
       and l.stat in (900,920,940,320,340)
       and l.time< venddate + 1
       and l.time>= vbegdate
       and A.client in (select gid from clienth where code like vvdrcode) ;

     --Ԥ��ʹ��
     insert into H4RTMP_VDRDocuments(vdrkey,cls,subject,num,ocrstat,ocrdate,total,stat)
     select a.vgid,'�տ�Ǽ�','Ԥ�տ�',a.num,l.stat,trunc(l.time),a.pretotal,a.stat
     from cpay a ,cpayLOG l
     where a.num = l.num
       and l.stat in (500,520,540)
       and l.time< venddate + 1
       and l.time>= vbegdate
       and A.vgid in (select gid from clienth where code like vvdrcode);

     commit;

end;
</BEFORERUN>
<AFTERRUN>
</AFTERRUN>
<TABLELIST>
  <TABLEITEM>
    <TABLE>H4RTMP_VDRDocuments</TABLE>
    <ALIAS>H4RTMP_VDRDocuments</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD>abc</INDEXMETHOD>
  </TABLEITEM>
  <TABLEITEM>
    <TABLE>MODULESTAT</TABLE>
    <ALIAS>MODULESTAT</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
  <TABLEITEM>
    <TABLE>MODULESTAT</TABLE>
    <ALIAS>MODULESTAT__1</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
  <TABLEITEM>
    <TABLE>CTCHGDEF</TABLE>
    <ALIAS>CTCHGDEF</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
  <TABLEITEM>
    <TABLE>CLIENTH</TABLE>
    <ALIAS>CLIENTH</ALIAS>
    <INDEXNAME></INDEXNAME>
    <INDEXMETHOD></INDEXMETHOD>
  </TABLEITEM>
</TABLELIST>
<JOINLIST>
  <JOINITEM>
    <LEFT>H4RTMP_VDRDocuments.vdrkey</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>CLIENTH.GID</RIGHT>
  </JOINITEM>
  <JOINITEM>
    <LEFT>MODULESTAT.NO</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>H4RTMP_VDRDocuments.ocrstat</RIGHT>
  </JOINITEM>
  <JOINITEM>
    <LEFT>MODULESTAT__1.NO</LEFT>
    <OPERATOR>=</OPERATOR>
    <RIGHT>H4RTMP_VDRDocuments.stat</RIGHT>
  </JOINITEM>
  <JOINITEM>
    <LEFT>H4RTMP_VDRDocuments.subject</LEFT>
    <OPERATOR>*=</OPERATOR>
    <RIGHT>CTCHGDEF.CODE</RIGHT>
  </JOINITEM>
</JOINLIST>
<COLUMNLIST>
  <FIXEDCOLUMNS>2</FIXEDCOLUMNS>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>CLIENTH.CODE</COLUMN>
    <TITLE>�ͻ�����</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>CODE1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>CLIENTH.NAME</COLUMN>
    <TITLE>�ͻ�����</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>NAME1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_VDRDocuments.cls</COLUMN>
    <TITLE>��������</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>cls</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>nvl( CTCHGDEF.NAME ,H4RTMP_VDRDocuments.subject)</COLUMN>
    <TITLE>��Ŀ</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>subject</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_VDRDocuments.num</COLUMN>
    <TITLE>���ݺ�</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>num</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_VDRDocuments.ocrdate</COLUMN>
    <TITLE>ҵ��������</TITLE>
    <FIELDTYPE>11</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>ocrdate</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>MODULESTAT.STATNAME</COLUMN>
    <TITLE>ҵ����״̬</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>STATNAME</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>H4RTMP_VDRDocuments.total</COLUMN>
    <TITLE>�������</TITLE>
    <FIELDTYPE>6</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>total</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>MODULESTAT__1.STATNAME</COLUMN>
    <TITLE>���ݵ�ǰ״̬</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>STATNAME1</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>decode(H4RTMP_VDRDocuments.rcvreg,1,'��','0','��')</COLUMN>
    <TITLE>�ͻ�����</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>rcvreg</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>decode(H4RTMP_VDRDocuments.ivcreg,1,'�ѵǼ�',0,'δ�Ǽ�')</COLUMN>
    <TITLE>��Ʊ�Ǽ�</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>ivcreg</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
  <COLUMNITEM>
    <AGGREGATION></AGGREGATION>
    <COLUMN>decode(H4RTMP_VDRDocuments.payreg,1,'�տ���',2,'���տ�',0,'δ�տ�')</COLUMN>
    <TITLE>�տ���</TITLE>
    <FIELDTYPE>1</FIELDTYPE>
    <VISIBLE>TRUE</VISIBLE>
    <GAGGREGATION></GAGGREGATION>
    <DISPLAYINNEXT>TRUE</DISPLAYINNEXT>
    <ISKEY>FALSE</ISKEY>
    <COLUMNNAME>payreg</COLUMNNAME>
    <CFILTER>FALSE</CFILTER>
    <CFONTCOLOR>0</CFONTCOLOR>
    <CDISFORMAT></CDISFORMAT>
    <CGROUPINDEX>-1</CGROUPINDEX>
  </COLUMNITEM>
</COLUMNLIST>
<COLUMNWIDTH>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>212</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>68</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>132</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>92</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>122</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>80</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>62</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>80</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
  <COLUMNWIDTHITEM>56</COLUMNWIDTHITEM>
</COLUMNWIDTH>
<GROUPLIST>
</GROUPLIST>
<ORDERLIST>
  <ORDERITEM>
    <COLUMN>ҵ��������</COLUMN>
    <ORDER>ASC</ORDER>
  </ORDERITEM>
</ORDERLIST>
<CRITERIALIST>
  <WIDTHLIST>
  </WIDTHLIST>
  <CRITERIAITEM>
    <LEFT>H4RTMP_VDRDocuments.ocrdate</LEFT>
    <OPERATOR>>=</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2010.09.26</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>����</DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>H4RTMP_VDRDocuments.ocrdate</LEFT>
    <OPERATOR><=</OPERATOR>
    <RIGHT>
      <RIGHTITEM>2010.11.04</RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>2</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE>����</DEFAULTVALUE>
    <ISREQUIRED>TRUE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>CLIENTH.CODE</LEFT>
    <OPERATOR>LIKE</OPERATOR>
    <RIGHT>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
    </PICKNAME>
    <PICKVALUE>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
  <CRITERIAITEM>
    <LEFT>H4RTMP_VDRDocuments.cls</LEFT>
    <OPERATOR>IN</OPERATOR>
    <RIGHT>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
      <RIGHTITEM></RIGHTITEM>
    </RIGHT>
    <ISHAVING>FALSE</ISHAVING>
    <ISQUOTED>0</ISQUOTED>
    <PICKNAME>
      <PICKNAMEITEM>������</PICKNAMEITEM>
      <PICKNAMEITEM>Ԥ�տ���</PICKNAMEITEM>
      <PICKNAMEITEM>������</PICKNAMEITEM>
      <PICKNAMEITEM>�ǻ�����</PICKNAMEITEM>
      <PICKNAMEITEM>�տ�Ǽ�</PICKNAMEITEM>
    </PICKNAME>
    <PICKVALUE>
      <PICKVALUEITEM>����,��������,������</PICKVALUEITEM>
      <PICKVALUEITEM>Ԥ���տ,Ԥ�ջ��</PICKVALUEITEM>
      <PICKVALUEITEM>�ͻ����õ�,�ͻ��տ</PICKVALUEITEM>
      <PICKVALUEITEM>�ͻ����õ�,�ͻ��տ,�տ�Ǽ�,Ԥ���տ,Ԥ�ջ��</PICKVALUEITEM>
      <PICKVALUEITEM>�տ�Ǽ�</PICKVALUEITEM>
    </PICKVALUE>
    <DEFAULTVALUE></DEFAULTVALUE>
    <ISREQUIRED>FALSE</ISREQUIRED>
    <WIDTH>0</WIDTH>
  </CRITERIAITEM>
</CRITERIALIST>
<CRITERIAWIDTH>
  <CRITERIAWIDTHITEM>138</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>149</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>135</CRITERIAWIDTHITEM>
  <CRITERIAWIDTHITEM>118</CRITERIAWIDTHITEM>
</CRITERIAWIDTH>
<SG>
  <LINE>
  </LINE>
  <LINE>
    <SGLINEITEM>���� 1��</SGLINEITEM>
    <SGLINEITEM>2010.09.26</SGLINEITEM>
    <SGLINEITEM>2010.11.04</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 2��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 3��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
    <SGLINEITEM>  �� 4��</SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
    <SGLINEITEM></SGLINEITEM>
  </LINE>
  <LINE>
  </LINE>
</SG>
<CHECKLIST>
  <CAPTION>
  </CAPTION>
  <EXPRESSION>
  </EXPRESSION>
  <CHECKED>
  </CHECKED>
  <ANDOR> and </ANDOR>
</CHECKLIST>
<UNIONLIST>
</UNIONLIST>
<NCRITERIAS>
  <NUMOFNEXTQRY>0</NUMOFNEXTQRY>
</NCRITERIAS>
<MULTIQUERIES>
  <NUMOFMULTIQRY>0</NUMOFMULTIQRY>
</MULTIQUERIES>
<FUNCTIONLIST>
</FUNCTIONLIST>
<DXDBGRIDITEM>
  <DXLOADMETHOD>FALSE</DXLOADMETHOD>
  <DXSHOWGROUP>FALSE</DXSHOWGROUP>
  <DXSHOWFOOTER>TRUE</DXSHOWFOOTER>
  <DXSHOWSUMMARY>FALSE</DXSHOWSUMMARY>
  <DXSHOWPREVIEW>FALSE</DXSHOWPREVIEW>
  <DXSHOWFILTER>FALSE</DXSHOWFILTER>
  <DXPREVIEWFIELD></DXPREVIEWFIELD>
  <DXCOLORODDROW>16777215</DXCOLORODDROW>
  <DXCOLOREVENROW>15921906</DXCOLOREVENROW>
  <DXFILTERNAME></DXFILTERNAME>
  <DXFILTERLIST>
  </DXFILTERLIST>
  <DXSHOWGRIDLINE>1</DXSHOWGRIDLINE>
</DXDBGRIDITEM>
</SQLQUERY>
<SQLREPORT>
<RPTTITLE>���ڶι�Ӧ�̵��ݻ��ܲ�ѯ</RPTTITLE>
<RPTGROUPCOUNT>0</RPTGROUPCOUNT>
<RPTGROUPLIST>
</RPTGROUPLIST>
<RPTCOLUMNCOUNT>23</RPTCOLUMNCOUNT>
<RPTCOLUMNWIDTHLIST>
  <RPTCOLUMNWIDTHITEM>90</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>170</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>97</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>92</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>79</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>109</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>101</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>103</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>89</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>88</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>104</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>92</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>101</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>90</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>105</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>89</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>102</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>106</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>109</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>85</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>80</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>87</RPTCOLUMNWIDTHITEM>
  <RPTCOLUMNWIDTHITEM>90</RPTCOLUMNWIDTHITEM>
</RPTCOLUMNWIDTHLIST>
<RPTLEFTMARGIN>20</RPTLEFTMARGIN>
<RPTORIENTATION>0</RPTORIENTATION>
<RPTCOLUMNS>1</RPTCOLUMNS>
<RPTHEADERLEVEL>0</RPTHEADERLEVEL>
<RPTPRINTCRITERIA>TRUE</RPTPRINTCRITERIA>
<RPTVERSION></RPTVERSION>
<RPTNOTE></RPTNOTE>
<RPTFONTSIZE>10</RPTFONTSIZE>
<RPTLINEHEIGHT>����</RPTLINEHEIGHT>
<RPTPAGEHEIGHT>66</RPTPAGEHEIGHT>
<RPTPAGEWIDTH>80</RPTPAGEWIDTH>
<RPTTITLETYPE>0</RPTTITLETYPE>
<RPTCURREPORT></RPTCURREPORT>
<RPTREPORTLIST>
</RPTREPORTLIST>
</SQLREPORT>

